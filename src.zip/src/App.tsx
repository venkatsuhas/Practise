import React from 'react';
import {Route,Link,HashRouter} from 'react-router-dom';
import Home from './components/home'
import BookList from './components/Booklist'
import {AddBook} from './components/Addbook'
import Details from './components/Details'
import './App.css'
class App extends React.Component{
  render(){
    return(
      <HashRouter>
        <div>
        <h1>Book Management System</h1>
        <ul className="header">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/books">Book List</Link></li>
          <li><Link to="/addbook">Add Books</Link></li>
        </ul>
        <Route exact path="/" component={Home}></Route>
        <Route exact path="/books" component={BookList}></Route>
        <Route exact path="/addbook" component={AddBook}></Route>
        <Route exact path="/details/:id?" component={Details}></Route>
        </div>
      </HashRouter>
    )
  }
}
export default App;
