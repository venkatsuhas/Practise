import {useState,useEffect} from 'react';
import {Route,Link,HashRouter} from 'react-router-dom';
import Home from './components/home'
import BookList from './components/Booklist'
import {AddBook} from './components/Addbook'
import Details from './components/Details'
import Register from './components/register'
import Login from './components/login'
import './App.css'
import {BookContextProvider} from './components/BookContext'


function App(){
  const [user,setUser]=useState(false)
  const [loginFailed,setLoginFailed]=useState<string>("")


  useEffect(()=>{
    if(localStorage.getItem("login")){
      setUser(true);
    }
  },[])

  const logout=async()=>{
    setUser(false);
    localStorage.clear();
  }

  const authentication=async (username:string,password:string)=>{
    
    let auth=await fetch("http://localhost:8000/users/login",{
      method:"POST",
      body:JSON.stringify({username:username,password:password}),
      headers:{"Content-Type":"application/json"}
    });
    
    let valid=await auth.json(); 
    if(valid==="Invalid"){
      setUser(false);
      setLoginFailed("failed");

    }else{
      localStorage.setItem("login",valid);
      setUser(true);
      setLoginFailed("success");
    }
  }
  const handleNewUser=async(newUser:any)=>{
    console.log("reg")
    await fetch("http://localhost:8000/users/registration",{
    method:"POST",
    body:JSON.stringify(newUser),
    headers:{"Content-Type":"application/json"}
    
    })
    // setUser(true);
    // setWindow(true);
  }
    return(
      <BookContextProvider>
      <HashRouter>
        <div>
        <h1>Book Management System</h1>
        <ul className="header">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/books">Book List</Link></li>
          <li>{user?<Link to="/addbook">Add Books</Link>:null}</li>
          <li>{user?null:<Link to="/register">Register</Link>}</li>
          <li>{user?null:<Link to="/login">Login</Link>}</li>
          <li>{user?<Link to="/" onClick={()=>logout()}>LogOut</Link>:null}</li>
        </ul>
        <Route exact path="/" component={Home}></Route>
        <Route exact path="/books" component={BookList}></Route>
        <Route exact path="/addbook" component={AddBook}></Route>
        <Route exact path="/details/:id?" component={Details}>
        </Route>
        <Route exact path="/register">
          <Register handleregistration={(newUser:any)=>{handleNewUser(newUser)}}></Register>
        </Route>
        <Route exact path="/login">
        <Login valid={loginFailed} handlelogin={(username,password)=>{authentication(username,password)}}></Login>
        </Route>
        </div>
      </HashRouter>
      </BookContextProvider>
    )
}
export default App;
