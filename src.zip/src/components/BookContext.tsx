import React, {createContext,useReducer, useEffect } from 'react';
import { bookReducer } from './bookReducer';

interface Iusercontext{
    books:[],
    dispatch:React.Dispatch<any>
}
const initialState={
    books:[
        {
            id: 2,
            isbn: "9781408855652",
            title: "Harry Potter and the Philosopher's Stone",
            author: "JK Rowling",
            pages: "352",
            price: "340",
            rating: "4.7",
            votes: "10192",
            description: "Harry Potter and the Philosopher's Stone was J.K. Rowling's first novel, followed by the subsequent six titles in the Harry Potter series, as well as three books written for charity: Fantastic Beasts and Where to Find Them, Quidditch Through the Ages and The Tales of Beedle the Bard. The Harry Potter novels have now sold over 450 million copies worldwide and been translated into 78 languages.",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "1",
            releaseDate: "1997-06-25T18:30:00.000Z",
            cover: "https://static.wikia.nocookie.net/warner-bros-entertainment/images/0/0e/Philostone.jpg/revision/latest?cb=20160307194850"
        },
        {
            id: 3,
            isbn: "1408855666",
            title: "Harry Potter and theHarry Potter and the Chamber of Secrets ",
            author: "JK Rowling",
            pages: "384",
            price: "259",
            rating: "4.7",
            votes: "8518",
            description: "Harry Potter's summer has included the worst birthday ever, doomy warnings from a house-elf called Dobby, and rescue from the Dursleys by his friend Ron Weasley in a magical flying car! Back at Hogwarts School of Witchcraft and Wizardry for his second year, Harry hears strange whispers echo through empty corridors - and then the attacks start. Students are found as though turned to stone . Dobby's sinister predictions seem to be coming true.",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "2",
            releaseDate: "1998-07-01T18:30:00.000Z",
            cover: "https://kbimages1-a.akamaihd.net/1c469dcb-5d48-47cb-a61b-5298babdb0d3/1200/1200/False/harry-potter-and-the-chamber-of-secrets-6.jpg"
        },
        {
            id: 4,
            isbn: "1408855674",
            title: "Harry Potter and the Prisoner of Azkaban ",
            author: "JK Rowling",
            pages: "480",
            price: "400",
            rating: "4.6",
            votes: "4850",
            description: "Harry Potter and the Chamber of Secrets is a fantasy novel written by British author J. K. Rowling and the second novel in the Harry Potter series. The plot follows Harry's second year at Hogwarts School of Witchcraft and Wizardry, during which a series of messages on the walls of the school's corridors warn that the 'Chamber of Secrets' has been opened and that the 'heir of Slytherin' would kill all pupils who do not come from all-magical families. These threats are found after attacks that leave residents of the school petrified. Throughout the year, Harry and his friends Ron and Hermione investigate the attacks.",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "3",
            releaseDate: "1999-07-08",
            cover: "https://kbimages1-a.akamaihd.net/69eca8ca-652c-4641-b86f-42de460a6d4d/1200/1200/False/harry-potter-and-the-prisoner-of-azkaban-6.jpg"
        },
        {
            id: 5,
            isbn: "1408855682",
            title: "Harry Potter and the Goblet of Fire",
            author: "JK Rowling",
            pages: "640",
            price: "450",
            rating: "4.7",
            votes: "4503",
            description: "Harry Potter and the Chamber of Secrets is a fantasy novel written by British author J. K. Rowling and the second novel in the Harry Potter series. The plot follows Harry's second year at Hogwarts School of Witchcraft and Wizardry, during which a series of messages on the walls of the school's corridors warn that the 'Chamber of Secrets' has been opened and that the 'heir of Slytherin' would kill all pupils who do not come from all-magical families. These threats are found after attacks that leave residents of the school petrified. Throughout the year, Harry and his friends Ron and Hermione investigate the attacks.",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "4",
            releaseDate: "2000-07-08",
            cover: "https://cdn11.bigcommerce.com/s-z7qq7adctg/images/stencil/500x659/products/674092/774560/btcl__84587.1522183285.jpg?c=2"
        },
        {
            id: 6,
            isbn: "9781408855690",
            title: "Harry Potter and the Order of the Phoenix",
            author: "JK Rowling",
            pages: "816",
            price: "509",
            rating: "4.7",
            votes: "4519",
            description: "",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "5",
            releaseDate: "2003-07-21",
            cover: "https://static.wikia.nocookie.net/harrypotter/images/3/31/Order_of_the_Phoenix_New_Cover.jpg/revision/latest?cb=20170109054726"
        },
        {
            id: 7,
            isbn: "9781408855706",
            title: "Harry Potter and the Half Blood Prince",
            author: "JK Rowling",
            pages: "560",
            price: "400",
            rating: "4.7",
            votes: "5651",
            description: "",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "6",
            releaseDate: "2005-07-25",
            cover: "https://cdn01.sapnaonline.com/product_media/9781408855706/md_9781408855706.jpg"
        },
        {
            id: 8,
            isbn: "1408894742",
            title: "Harry Potter and the Deathly Hallows",
            author: "JK Rowling",
            pages: "640",
            price: "550",
            rating: "4.7",
            votes: "7262",
            description: "Harry Potter and the Deathly Hallows is a fantasy novel written by British author J. K. Rowling and the seventh and final novel of the Harry Potter series. It was released on 21 July 2007 in the United Kingdom by Bloomsbury Publishing, in the United States by Scholastic, and in Canada by Raincoast Books. The novel chronicles the events directly following Harry Potter and the Half-Blood Prince (2005) and the final confrontation between the wizards Harry Potter and Lord Voldemort.",
            tags: [
                "harry potter",
                "fiction",
                "fantasy",
                "best-seller"
            ],
            series: "Harry Potter",
            seriesIndex: "7",
            releaseDate: "2007-07-21",
            cover: "https://images-na.ssl-images-amazon.com/images/I/811t1pfIZXL.jpg"
        },
        {
            id: 9,
            isbn: "9781509808694",
            title: "Kane and Abel",
            author: "Jeffrey Archer",
            pages: "250",
            price: "199",
            rating: "4.1",
            votes: "2367",
            description: "They had only one thing in common . . . William Lowell Kane and Abel Rosnovski: one the son of a Boston millionaire, the other of a penniless Polish immigrant. Two men born on the same day, on opposite sides of the world, their paths destined to cross in the ruthless struggle to build a fortune. A memorable story, spanning sixty years, of two powerful men linked by an all-consuming hatred, brought together by fate to save – and finally destroy – each other. ‘The ultimate novel of sibling rivalry’ Dan Brown",
            tags: [
                "fiction",
                "classic",
                "chronology",
                "english"
            ],
            series: "",
            seriesIndex: "",
            releaseDate: "1979-01-01",
            cover: "https://images-na.ssl-images-amazon.com/images/I/81Y8QLPFFlL.jpg"
        },
        {
            id: 10,
            isbn: " 8193387627",
            title: "The Count of Monte Cristo",
            author: "Alexandre Dumas",
            pages: "932",
            price: "350",
            rating: "4.5",
            votes: "1139",
            description: "The Count of Monte Cristo (French: Le Comte de Monte-Cristo) is an adventure novel by French author Alexandre Dumas (père) completed in 1844. It is one of the author's more popular works, along with The Three Musketeers. Like many of his novels, it was expanded from plot outlines suggested by his collaborating ghostwriter Auguste Maquet.[1] Another important work by Dumas, written before his work with Maquet, was the 1843 short novel Georges; this novel is of particular interest to scholars because Dumas reused many of the ideas and plot devices later in The Count of Monte Cristo.[2] The story takes place in France, Italy, and islands in the Mediterranean during the historical events of 1815–1839: the era of the Bourbon Restoration through the reign of Louis-Philippe of France. It begins just before the Hundred Days period (when Napoleon returned to power after his exile). The historical setting is a fundamental element of the book, an adventure story primarily concerned with themes of hope, justice, vengeance, mercy, and forgiveness. It centres on a man who is wrongfully imprisoned, escapes from jail, acquires a fortune, and sets about exacting revenge on those responsible for his imprisonment. His plans have devastating consequences for both the innocent and the guilty. The book is considered a literary classic today. ",
            tags: [
                "fiction",
                "classic",
                "best-seller",
                "historic fiction",
                "adventure"
            ],
            series: "",
            seriesIndex: "",
            releaseDate: "1886-01-01",
            cover: "https://images-na.ssl-images-amazon.com/images/I/61qF6xsWq3L.jpg"
        },
        {
            id: 11,
            isbn: "0007527519",
            title: "Five Little Pigs",
            author: "Agatha Christie",
            pages: "288",
            price: "180",
            rating: "4.6",
            votes: "605",
            description: "The Count of Monte Cristo (French: Le Comte de Monte-Cristo) is an adventure novel by French author Alexandre Dumas (père) completed in 1844. It is one of the author's more popular works, along with The Three Musketeers. Like many of his novels, it was expanded from plot outlines suggested by his collaborating ghostwriter Auguste Maquet.[1] Another important work by Dumas, written before his work with Maquet, was the 1843 short novel Georges; this novel is of particular interest to scholars because Dumas reused many of the ideas and plot devices later in The Count of Monte Cristo.[2] The story takes place in France, Italy, and islands in the Mediterranean during the historical events of 1815–1839: the era of the Bourbon Restoration through the reign of Louis-Philippe of France. It begins just before the Hundred Days period (when Napoleon returned to power after his exile). The historical setting is a fundamental element of the book, an adventure story primarily concerned with themes of hope, justice, vengeance, mercy, and forgiveness. It centres on a man who is wrongfully imprisoned, escapes from jail, acquires a fortune, and sets about exacting revenge on those responsible for his imprisonment. His plans have devastating consequences for both the innocent and the guilty. The book is considered a literary classic today. ",
            tags: [
                "fiction",
                "detective",
                "hercule poirot",
                "suspense",
                "murder"
            ],
            series: "Hercule Poirot",
            seriesIndex: "",
            releaseDate: "1942-05-01",
            cover: "https://kbimages1-a.akamaihd.net/d54608a2-1499-47eb-bd78-e96b384c49e5/1200/1200/False/five-little-pigs.jpg"
        },
        {
            id: 12,
            isbn: "8129135728",
            title: "Half Girl Friend",
            author: "Chetan Bhagat",
            pages: "280",
            price: "180",
            rating: "3.2",
            votes: "8300",
            description: "Half Girlfriend is an Indian English coming of age, young adult romance novel by Indian author Chetan Bhagat.[1] The novel, set in rural Bihar, New Delhi, Patna, and New York, is the story of a Bihari boy in quest of winning over the girl he loves.[2][3] This is Bhagat's sixth novel which was released on 1 October 2014[4] by Rupa Publications. The novel has also been published in Hindi[5] and Gujarati[6] versions as well. Dedicated to 'non English-types', as Chetan Bhagat wrote, the book divulges the sentiments and linguistic struggles of a backward rural Bhojpuri-laced Hindi-speaking boy from Bihar as he enrolls himself at the prestigious English-medium St. Stephen’s College, New Delhi, and falls in love with a 'high class English-speaking rich Delhi girl' schooled at Modern School, New Delhi. The girl does not admit the relationship but agrees to be his 'half girlfriend'.[7] Chetan Bhagat commented, 'Half-Girlfriend, to me, is a unique Indian phenomenon, where boys and girls are not clear about their relationship status with each other. A boy may think he is more than friends with the girl, but the girl is still not his girlfriend. Hence, I thought we needed a term like 'Half girlfriend'. Because, in India, that is what most men get.'[7]",
            tags: [
                "fiction",
                "indian",
                "young adult",
                "college",
                "romance"
            ],
            series: "",
            seriesIndex: "",
            releaseDate: "2017-05-19",
            cover: "https://images-na.ssl-images-amazon.com/images/I/712HEn9SNwL.jpg"
        },
        {
            id: "13",
            title: "pirates",
            author: "sparrow",
            rating: "8",
            price: "6000"
        }
    ]

}
const BookContext = React.createContext<Iusercontext>({} as Iusercontext);

export const BookContextProvider = (props:any) => {
  const [books, dispatch] = useReducer(bookReducer,initialState,()=>{
      return initialState.books.length>0?initialState.books:[];
  })

  return (
    <BookContext.Provider value={{ books, dispatch }}>
      {props.children}
    </BookContext.Provider>
  );
};

// export {BookContextProvider}
export default BookContext;