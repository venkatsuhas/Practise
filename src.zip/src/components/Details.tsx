import React, { Component} from "react";
import {RouteComponentProps,HashRouter,Route,Link } from "react-router-dom";
import {books} from "./Addbook"
import BookList from "./Booklist"
class Details extends Component<RouteComponentProps<any>>{
    constructor(props:any){
        super(props);
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick(index:any){
        books.splice(index,1);
        localStorage.setItem("books",JSON.stringify(books));
    }
    render(){
        const id=this.props.match.params.id;
        return(
            <div>
               {books.map((book:any,index:any) =>{
                   if(book.id===id){
                       return(
                        <div className="card">
                        <img id="imgDetails" src={book.cover} alt={book.title}/>
                        <p><strong>Author:{book.author}</strong></p> 
                        <p><strong>Rating:{book.rating}</strong></p>
                        <p><strong>Price :₹{book.price}</strong></p>
                        <h2>{book.title}</h2>
                        <p><strong>{book.description}</strong></p>
                        <button id='del-button' onClick={() => this.handleClick(index)}>
                        <HashRouter>
                        <Link to={"/books"}>
                        DELETE
                        </Link>
                        <Route exact path='/books' component={BookList}></Route>
                        </HashRouter>
                        </button>
                        </div>
                       );
                   }
                   return null;
               })}
            </div>
        );
    }
}
export default Details;