
import { useState ,useContext} from "react";
import {useHistory } from "react-router-dom";
// import {books} from "./Addbook"
import Star from './star-component'
import BookContextProvider from './BookContext'


function Details(props:any){
    
    const{books,dispatch}=useContext(BookContextProvider)
    const history = useHistory();
    const id=props.match.params.id;
    // console.log(id);
    
    let bookDetail = books.map((book:any,index)=>{
        if(book.id===id){
            console.log(book);
            
            
        return(
            <div>
                        <div className="card">
                        <img id="imgDetails" src={book.cover} alt={book.title}/>
                        <p><strong>Author:{book.author}</strong></p> 
                        {/* <p><strong>Rating:{book.rating}</strong></p> */}
                        <Star value={book.rating}></Star>
                        <p><strong>Price :₹{book.price}</strong></p>
                        <h2>{book.title}</h2>
                        <p><strong>{book.description}</strong></p>
                        {/* {props.valid==="success"?<button id='del-button' onClick={handleClick}>Delete</button>:null} */}
                        <button id='del-button' onClick={()=>{dispatch({type:"DELETE",id:book.id});history.push("/books");}}>Delete</button>
                        </div>
            </div>
        );
            }
    })
    return (
        
        <div>
            {bookDetail}
        </div>
        
    )
}
export default Details;