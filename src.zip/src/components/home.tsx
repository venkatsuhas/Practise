import React from 'react';

class Home extends React.Component{
    render(){
        return(
            <div>
                <h2>This is Home</h2>
            </div>
        )
    }
}

export default Home;