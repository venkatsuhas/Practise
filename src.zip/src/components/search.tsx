import { useState } from "react";

function SearchBar(props: any) {
  const [searchInput, setSearchInput] = useState("");
  const [selected,setSelected] = useState("");

  function handleSearch(event: any) {
    setSearchInput(event.target.value);
  }
  function handleChange(event: any) {
    setSelected(event.target.value);
  }
  return (
    <div className="searchDiv">
      <select className="select" onChange={handleChange}>
        <option value="text">Select</option>
        <option value="id">Id</option>
        <option value="author">Author</option>
        <option value="title">Title</option>
        <option value="rating">Rating</option>
        <option value="price">price</option>
        <option value="text">Text</option>
      </select>
      <input
      className="search"
        type="text"
        name="id"
        required
        placeholder="Enter here to search"
        onChange={handleSearch}
      />
      <button
        id="search-button"
        type="submit"
        onClick={() => props.onSearch(searchInput,selected)}
      >
        Search
      </button>
    </div>
  );
}

export default SearchBar;