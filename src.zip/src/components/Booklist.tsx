import { Route, NavLink } from "react-router-dom";
import Details from "./Details";
import SearchBar from "./search";
import { useState, useEffect ,useContext} from "react";
import Star from "./star-component";
import BookContextProvider from './BookContext'

function BookList(props: any) {
  const{books}=useContext(BookContextProvider)

  return (
    <div>
      {/* <SearchBar onSearch={handleSearchSubmit}></SearchBar> */}
      {/* eslint-disable-next-line */}
      {books.map(function (book: any, index: any) {
        return (
          <div>
            <NavLink key={book.id} to={"/details/" + book.id}>
              <div className="book-card" id={book.id}>
                <br />
                <img id="img" src={book.cover} alt={book.title} />
                <h3>{book.title}</h3>
                {/* <p>Rating:{book.rating}</p> */}
                <Star value={book.rating} />
                <p className="price">
                  <strong>₹{book.price}</strong>
                </p>
              </div>
            </NavLink>
            <Route path={"/details/" + book.id} component={Details} />
          </div>
        );
      })}
            
    </div>
  );
}

export default BookList;