import React from 'react';
import {Route,NavLink,HashRouter} from 'react-router-dom';
import {books} from './Addbook';
import Details from './Details'

class BookList extends React.Component{
    render(){
        return(
            <div>
                {books.map((book:any,index:any)=>{
                    return(
                        <HashRouter>
                            <NavLink to={"/details/"+book.id}>
                                <div className="book-card" id={book.id}>
                                    <br/>
                                    <img id="img" src={book.cover} alt={book.title}/>
                                    <h3>{book.title}</h3>
                                    <p className="price">
                                        <strong>${book.price}</strong>
                                    </p>
                                </div>
                            </NavLink>
                            <Route path={"/details"+book.id} component={Details}></Route>
                        </HashRouter>
                    )
                })}
            </div>
        )
    }
}
export default BookList;