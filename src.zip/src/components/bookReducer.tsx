
type Action = |{type:"ADDBOOK",book:[]}
            |{type:"DELETE",id:String}
            |{type:"LIST"}
export const bookReducer = (state:[], action:Action):any => {
  switch (action.type) {
    case 'ADDBOOK':
      console.log(action.book);
      return [
        ...state.concat(action.book)
      ];
    case 'DELETE':
      console.log(action.id);
      return state.filter((book:any)=> book.id !== action.id);
    default:
      return state;
  }
};