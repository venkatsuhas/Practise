import React, { useState } from "react";
import {Route,Link,HashRouter} from 'react-router-dom';
import BookList from "./Booklist";

let books:any = localStorage.getItem("books");
if(!books){
    books=[];
}
else{
    books=JSON.parse(books);
}

  function AddBook(){
    const [id,setId] = useState("");
    const [title,setTitle] = useState("");
    const [author,setAuthor] = useState("");
    const [price,setPrice] = useState("");
    const [rating,setRating] = useState("");
    const [description,setDescription] = useState("");
    const [cover,setCover] = useState("");


    function handleIdChange(e:any) {
      setId(e.target.value);
      
    }
    function handleTitleChange(e:any) {
      setTitle(e.target.value);
    }
    function handleAuthorChange(e:any) {
      setAuthor(e.target.value);
      
    }
    function handlePriceChange(e:any) {
      setPrice(e.target.value);
      
    }
    function handleRatingChange(e:any) {
      setRating(e.target.value);
      
    }
    function handleDesChange(e:any) {
      setDescription(e.target.value);
      
    }
    function handleCoverChange(e:any) {
      setCover(e.target.value);
      
    }
  function handleSubmit(event:any){
    // const {id,title,author,price,rating,description,cover} = this.state;
    event.preventDefault();
    const book={
        id:id,
        title:title,
        author:author,
        price:price,
        rating:rating,
        description:description,
        cover:cover
    }
    if(book){
    books.push(book);
    localStorage.setItem("books",JSON.stringify(books));
    }
    
}
    return (
      <div className="book-form">
        
  <form className="form-area">
    <h2>ADD NEW BOOK</h2>
        <hr/>
    <div>
        <label htmlFor='id'>Book Id : </label>
        <input type="text" name="id" placeholder="Book id"  value={id} onChange={handleIdChange} required/>
    </div><br/>
    <div>
        <label htmlFor='title'>Title : </label>
        <input type="text" name="title" placeholder="Book title" value={title} onChange={handleTitleChange}/>
    </div><br/>
   <div>
        <label htmlFor='author'>Author : </label>
        <input type="text" name="author" placeholder="Author" value={author} onChange={handleAuthorChange}/>
   </div><br/>
   <div>
        <label htmlFor='price'>Price : </label>
        <input type="text" name="price" placeholder="Price" value={price} onChange={handlePriceChange}/>
   </div><br/>
    <div>
        <label htmlFor='rating'>Rating : </label>
        <input type="text" name="rating" placeholder="Rating" value={rating} onChange={handleRatingChange}/>
    </div><br/>
    <div>
        <label htmlFor='description'>Description : </label>
        <textarea name="description" placeholder="Description" value={description} onChange={handleDesChange}></textarea>
    </div><br/>
    <div>
        <label htmlFor='cover'>Cover : </label>
        <input type="text" name="cover" placeholder="cover" value={cover} onChange={handleCoverChange}/>
    </div><br/>
    <div>
    <button id="add-button" type="submit" onClick={handleSubmit}>
        <HashRouter>
        <Link to={"/books"}>
        ADD
        </Link>
        <Route exact path='/books' component={BookList}></Route>
        </HashRouter>
        </button>

    </div><br/>
  </form>
      </div>
    );
  }
 
export {AddBook,books};