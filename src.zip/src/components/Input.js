import React from 'react';
class InputComponent extends React.Component{
  constructor(props){
    super(props);
    this.state={
      player:"",
    }
  }
  handleChange=(e)=>{
    this.setState({player:e.target.value})
    // console.log(e.target.value);
    console.log("hello");
  }
  render(){
    return (
      <>
      <label>{this.props.label}</label>
      <input type="text" value={this.state.player} onchange={this.handleChange}></input>
      <button onClick={()=>this.props.handleName(this.state.player,this.props.label)}>Submit</button>
      </>
    )
  }
}
export default InputComponent;