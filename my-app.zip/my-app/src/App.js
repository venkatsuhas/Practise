import React from "react";
import "./App.css";
import Greetings from "./greetings";
import showError from "./showError";
import { ErrorBoundary } from "react-error-boundary";
function App() {
  // eslint-disable-next-line no-unused-vars
  let User = {
    firstName: "Bhanu",
    lastName: "Boligonda",
  };
  return (
    <div className="App">
      <ErrorBoundary FallbackComponent={showError}>
        <Greetings User={null} role="admin" />
      </ErrorBoundary>
      <ErrorBoundary FallbackComponent={showError}>
        <Greetings User={User} role="guest" />
      </ErrorBoundary>
      <ErrorBoundary FallbackComponent={showError}>
        <Greetings User={User} role="admin" />
      </ErrorBoundary>
    </div>
  );
}

export default App;
