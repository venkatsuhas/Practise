import axios from "axios";

export class ServiceManager {
  getAllBooks = async (dispatch: any) => {
    await axios
      .get("http://localhost:8000/books")
      .then(response => {
        dispatch({ type: "BOOK_LIST", BookList: response.data });
      })
      .catch(err => {
        console.log(err.message);
      });
  };

  getAllBooksForTest=async()=>{
    let response=await axios.get("http://localhost:8000/books")
    return response.data;
  }

  getAllAuthors = async (dispatch: any) => {
    await axios
      .get("http://localhost:8000/authors")
      .then(response => {
        dispatch({ type: "AUTHOR_LIST", authorList: response.data });
      })
      .catch(err => {
        console.log(err.message);
      });
  };

  getBooksByAuthorName = async (dispatch: any, author: any) => {
    await axios
      .get("http://localhost:8000/books/by/author/" + author)
      .then(response => {
        dispatch({ type: "AUTHORS_BOOKS", authorsBooks: response.data });
      })
      .catch(err => {
        console.log(err.message);
      });
  };

  
  addUsers = async (dispatch: any, user: any) => {
    console.log(user, "user1");

    let check = await axios.post(
      "http://localhost:8000/users/registration",
      user,
      {
        headers: { "Content-Type": "application/json" },
      }
    );
    if (check.status === 200) {
      dispatch({ type: "REGISTER", addUser: user });
    }
  };
}
