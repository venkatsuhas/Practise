import {ServiceManager} from "../service-layer";
let services= new ServiceManager();

it("calls axios and return the books",()=>{
    const books=services.getAllBooksForTest();
    console.log(books);
    
});