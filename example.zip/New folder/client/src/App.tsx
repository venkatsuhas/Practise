import { Route, Link, BrowserRouter } from "react-router-dom";
import AuthorList from "./components/authorlist";
import { useState, useEffect } from "react";
import "./App.css";
// import "./Nav.css";
import Register from "./components/registration";
import Login from "./components/login";




function App() {
  const [user, setUser] = useState(false);
  const [loginFailed, setLoginFailed] = useState("");

  useEffect(() => {
    if (localStorage.getItem("login")) {
      setUser(true);
    }
  }, []);

  const logout = async () => {
    setUser(false);
    localStorage.clear();
  };

  const authentication = async (username: string, password: string) => {
    console.log(username, password);

    let auth = await fetch("http://localhost:8000/users/login", {
      method: "POST",
      body: JSON.stringify({ username: username, password: password }),
      headers: { "content-type": "application/json" },
    });
    let valid = await auth.json();
    console.log(valid, "valid")
    if (valid === 401) {
      setUser(false);
      setLoginFailed("failed");
      return false;
    } else {
      console.log("Login Success", valid);

      localStorage.setItem("login", valid);
      setUser(true);
      setLoginFailed("success");
      return true;
    }
  };
  const handleNewUser = async (newUser: any) => {
    console.log("reg");
    await fetch("http://localhost:8000/users/registration", {
      method: "POST",
      body: JSON.stringify(newUser),
      headers: { "Content-Type": "application/json" },
    });
    console.log("reg2");
  };
  return (
    <BrowserRouter>
      <div>
        <h1>Famous Authors</h1>
        <div className="header">
         
          
            <div>
              <ul>
            <li><Link to="/authors">Author List</Link></li>
          </ul>
            </div>

        </div>
        <Route exact path="/" component={AuthorList}></Route>
        <Route exact path="/authors" component={AuthorList}></Route>
        <Route exact path="/register">
          <Register
            handleregistration={(newUser: any) => {
              handleNewUser(newUser);
            }}
          ></Register>
        </Route>
        <Route exact path="/login">
          <Login valid={loginFailed} handlelogin={authentication}></Login>
        </Route>
      </div>
    </BrowserRouter>
  );
}
export default App;
