
//the real axios looks like na object witg get property
//here creating a fake function that look similar to the catual one
//fake functio but has some special capabilities like 
//---how many times calle what arguments its called with

// since original axios calls deals with promise we nees to instatantly resolve it 
//initially imagine data is null
export const mocking= {
    get:jest.fn(()=>Promise.resolve({data:null}))
}

