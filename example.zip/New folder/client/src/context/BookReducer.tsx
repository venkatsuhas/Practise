export const Reducer = (state: any, action: any): any => {
  switch (action.type) {
    case "BOOK_LIST":
      console.log(action.BookList);
      return {
        ...state,
        books: action.BookList,
      };
    case "AUTHOR_LIST":
      console.log(action.BookList);
      return {
        ...state,
        authors: action.authorList,
      };
    case "AUTHORS_BOOKS":
      return {
        ...state,
        clicked: true,
        authorsBooks: action.authorsBooks,
      };

    default:
      return state;
  }
};
