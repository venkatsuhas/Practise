import React, { useReducer } from "react";
import { Reducer } from "./BookReducer";

export const BookContext = React.createContext<any>({});

export const BookProvider = (props: any) => {
  const [state, dispatch] = useReducer(Reducer, {}, () => {
    return {
      books: [],
      authorsBooks: [],
      authors: [],
      isLoggedIn: false,
      clicked:false
    };
  });

  return (
    <BookContext.Provider value={{ state, dispatch }}>
      {props.children}
    </BookContext.Provider>
  );
};
