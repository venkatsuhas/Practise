// import { Route, NavLink } from "react-router-dom";
import { useContext, useEffect } from "react";
import { ServiceManager } from "../services/service-layer";
import { BookContext } from "../context/BookContext";
import AuthorBooks from "./AuthorBooks";

function AuthorList(props: any) {
  const { state } = useContext(BookContext);
  const { dispatch } = useContext(BookContext);
  // const [click, setClick] = useState(false);

  console.log("state in author list",state);
console.log("dispatch in list",dispatch);

  const service = new ServiceManager();

  useEffect(() => {
    service.getAllBooks(dispatch);
    service.getAllAuthors(dispatch);
    // eslint-disable-next-line
  }, []);
  const authors = state.authors;
  
  return (
    <div>
      <h2>Authors...</h2>
      {/* eslint-disable-next-line */}
      <div className="authorContainer">
        <div className="authors">
          {authors.map((author: any, index: any) => {
            return (
              <div>
                <br />
                <h5
                  id="author-list"
                  onClick={() => {
                    service.getBooksByAuthorName(dispatch, author);
                  }}
                >
                  <li>{author}</li>
                </h5>
              </div>
            );
          })}
        </div>
        <div className="authorBooks">
          <AuthorBooks />
        </div>
      </div>
    </div>
  );
}

export default AuthorList;
