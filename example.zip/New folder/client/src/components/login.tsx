import React, { useState } from "react";
// import { Route, Link, HashRouter } from "react-router-dom";
import { Button, Col, Form } from "react-bootstrap";
// import Home from "./home";
import "bootstrap/dist/css/bootstrap.min.css";
import { useHistory } from "react-router-dom";
import { useContext } from "react";
import { BookContext } from "../context/BookContext";

// eslint-disable-next-line
interface props {
  valid: string;
  handlelogin: (username: string, password: string) => void;
}
const Login: React.FC<props> = (props: any) => {

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const history = useHistory();

  function inputlusername(e: any) {
    setUsername(e.target.value);
  }
  function inputlpassword(e: any) {
    setPassword(e.target.value);
  }
  async function doLogin() {
    let success = await props.handlelogin(username, password);
    console.log("success", success);

    if (success) {
      history.push("/authors");
    }
  }

  return (
    <>
      <br />
      <Form>
        <Form.Group as={Col} controlId="formGridEmail">
          <Form.Label>User Name </Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            onChange={inputlusername}
          />
        </Form.Group>
        <Form.Group as={Col} controlId="formGridPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            onChange={inputlpassword}
          />
        </Form.Group>
      </Form>
      <br />

      <Button variant="success" type="button" onClick={doLogin}>
        Log in
      </Button>
      {props.valid === "failed" ? (
        <h3 style={{ color: "red" }}>Invalid Username or Password</h3>
      ) : null}
    </>
  );
};
export default Login;
