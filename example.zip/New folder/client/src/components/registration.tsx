import { useState, useContext } from "react";
import { useHistory } from "react-router-dom";
import { Button, Form, Col } from "react-bootstrap";
import { BookContext } from "../context/BookContext";
import { ServiceManager } from "../services/service-layer";

const Register = (props: any) => {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [phonenumber, setPhonenumber] = useState("");
  const [address, setAddress] = useState("");
  const { dispatch } = useContext(BookContext);
  const history = useHistory();
  function inputusername(e: any) {
    setUserName(e.target.value);
  }
  function inputpassword(e: any) {
    setPassword(e.target.value);
  }
  function inputphonenumber(e: any) {
    setPhonenumber(e.target.value);
  }
  function inputaddress(e: any) {
    setAddress(e.target.value);
  }
  const service = new ServiceManager();
  function handleSubmit() {
    const user = {
      username: username,
      password: password,
      phonenumber: phonenumber,
      address: address,
    };
    service.addUsers(dispatch, user);
  }

  return (
    <>
      <Form>
        <Form.Group as={Col} controlId="formGridEmail">
          <Form.Label>User Name</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            onChange={inputusername}
            required
          />
        </Form.Group>
        <Form.Row>
          <Form.Group as={Col} controlId="formGridPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              onChange={inputpassword}
              required
            />
          </Form.Group>
          <Form.Group as={Col} controlId="formGridPassword">
            <Form.Label>Phone number</Form.Label>
            <Form.Control
              type="email"
              placeholder="Phone number"
              onChange={inputphonenumber}
              required
            />
          </Form.Group>
        </Form.Row>
        <Form.Group as={Col} controlId="formGridEmail">
          <Form.Label>Address</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter Address"
            onChange={inputaddress}
            required
          />
        </Form.Group>
      </Form>
      <Button
        className="style"
        variant="success"
        type="button"
        onClick={() => {
          handleSubmit();
          history.push("/login");
        }}
      >
        Register
      </Button>
    </>
  );
};
export default Register;
