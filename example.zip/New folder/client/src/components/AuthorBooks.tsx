import { useContext, useEffect } from "react";
import { ServiceManager } from "../services/service-layer";
import { BookContext } from "../context/BookContext";

function AuthorsBooks(props: any) {
  const { state, dispatch } = useContext(BookContext);
  // const { dispatch } = useContext(BookContext);

  let authorBooks = state.authorsBooks;

  const service = new ServiceManager();

  useEffect(() => {
    service.getAllBooks(dispatch);
    // eslint-disable-next-line
  }, [state]);

  return (
    <div>
      {/* eslint-disable-next-line */}
      <div>
        {authorBooks.length !== 0
          ? authorBooks.map((book: any, index: any) => {
              return (
                <div>
                    <div
                      className="book-card"
                      id={book._id}

                    >
                      <br />
                      <img id="img" src={book.cover} alt={book.title} />
                      <h3>{book.title}</h3>
                      <p className="price">
                        <strong>₹{book.price}</strong>
                      </p>
                    </div>
                </div>
              );
            })
          : null}
      </div>
    </div>
  );
}

export default AuthorsBooks;
