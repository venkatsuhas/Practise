import express from "express";
import book from "../models/bookModel";
export const router = express.Router();
import { authenticate } from "./loginHandler";

// /books

router.get("/", async (req: any, res: any) => {
  try {
    const books = await book.find();
    res.json(books);
  } catch (err) {
    res.send("Error " + err);
  }
});

router.get("/by/author/:author", async (req: any, res: any) => {
  try {
    const books = await book.find({ author: req.params.author });
    //    res.json(books)
    res.send(JSON.stringify(books));
  } catch (err) {
    res.send("Error " + err);
  }
});

router.get("/by/title/:title", async (req: any, res: any) => {
  try {
    const title = new RegExp(req.params.title, "i");
    const books = await book.find({ title });
    //    res.json(books)
    res.send(books);
  } catch (err) {
    res.send("Error " + err);
  }
});

router.get("/by/rating/:rating", async (req: any, res: any) => {
  try {
    let books = await book.find({ rating: { $gte: req.params.rating } });
    // console.log(JSON.stringify(books))
    res.send(books);
  } catch (err) {
    res.send("Error " + err);
  }
});

router.get("/priced/:min/:max", async (req: any, res: any) => {
  try {
    console.log(req.params.min);
    let books = await book.find({
      $and: [
        { price: { $gte: req.params.min } },

        { price: { $lte: req.params.max } },
      ],
    });
    // console.log(JSON.stringify(books))
    res.send(books);
  } catch (err) {
    res.send("Error " + err);
  }
});

router.post("/", authenticate, async (req: any, res: any) => {
  const books = new book({
    // console.log("hii");
    title: req.body.title,
    author: req.body.author,
    rating: req.body.rating,
    price: req.body.price,
    description: req.body.description,
    cover: req.body.cover,
  });

  try {
    // console.log("hii");
    const a1 = await books.save();
    // console.log("hello");
    res.json(a1);
  } catch (err) {
    res.send("Error");
  }
});

router.get("/authors", async (req: any, res: any) => {
  try {
    let books = await book.distinct("author");
    res.status(200).send(books);
    console.log("my authors list", books);
  } catch (err: any) {
    res.send(400).send("something went wrong");
    console.log(err, "error");
  }
});

router
  .route("/:id")
  .get(async (req: any, res: any) => {
    try {
      const books = await book.findById(req.params.id);
      res.json(books);
    } catch (err) {
      res.send("Error " + err);
    }
  })
  .patch(authenticate, async (req: any, res: any) => {
    try {
      const books: any | null = await book.findById(req.params.id);
      if (req.body.title) books.title = req.body.title;
      if (req.body.author) {
        // console.log("hii");
        books.author = req.body.author;
      }
      if (req.body.rating) books.rating = req.body.rating;
      if (req.body.price) books.price = req.body.price;
      const a1 = await books.save();
      res.json(a1);
    } catch (err) {
      res.send("Error");
    }
  })

  .delete(authenticate, async (req: any, res: any) => {
    try {
      const books: any | null = await book.findById(req.params.id);
      // books.sub = req.body.sub
      const a1 = await books.remove();
      res.json(a1);
    } catch (err) {
      res.send("Error");
    }
  });

let flag: any = false;
// router.get("/authors/list", async (req: any, res: any) => {
//   try {
//     let authors: any[] = [];
//     let books = await book.find();
//     books.forEach((book: any) => {
//       if (authors.length === 0) {
//         authors.push(book.author);
//       } else {
//         isPresent(book.author, authors);
//         if (!flag) {
//           authors.push(book.author);
//         }
//       }
//     });
//     res.status(200).send(authors);
//   } catch (err: any) {
//     res.status(400).send("ERROR", err.message);
//   }
// });

function isPresent(author: any, authorArray: any[]): any {
  authorArray.forEach((item: any) => {
    if (item === author) {
      flag = true;
    } else {
      flag = false;
    }
  });
}

// localhost:8000/books/authors
