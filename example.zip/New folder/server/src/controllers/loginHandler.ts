import express from "express";
import User from "../models/registartionSchema";
import jwt from "jsonwebtoken";
const bcrypt = require("bcryptjs");
export const userRouter = express.Router();

userRouter.post("/login", async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ msg: "credential missing" });
  }
  User.findOne({ username }).then((user: any) => {
    if (!user) return res.status(400).json({ msg: "user doesnot exists" });
    //validate password
    bcrypt.compare(password, user.password).then((isMatch: any) => {
      //   if (!isMatch) return res.status(400).json({ msg: "invalid credentials" });
      if (!isMatch) return res.json(401);

      jwt.sign(
        { id: user._id },
        `${process.env.jwtSecret}`,
        { expiresIn: 3600 },
        (err: any, token: any) => {
          if (err) throw err;
          res.json(token);
        }
      );
    });
  });
});

// const accountSid = process.env.TWILIO_ACCOUNT_SID;
// const authToken = process.env.TWILIO_AUTH_TOKEN;

// const client = require("twilio")(accountSid, authToken);

// function otpGenerator(req: any, res: any) {
//   const otp = Math.floor(100000 + Math.random() * 900000);
//   const timeTaken = 2 * 60 * 60;
//   const expires = Date.now() + timeTaken;
//   client.messages
//     .create({
//       body: `Your One Time Login Password is ${otp}`,
//       from: process.env.PHONE_NUMBER,
//       to: +916303473368,
//     })
//     .then(async (response: any) => {
//       await User.updateOne({ otp: otp, time: expires });
//     })
//     .catch((err: any) => {
//       console.log(err.message);
//     });

//   res.status(200).send({ msg: "OTP sent" });
// }

// userRouter.post("/otpverification", async (req:any, res:any) => {
//   const otp = req.body.otp;
//   if (otp) {
//     try {
//       const authentication = await User.findOne({ otp: otp });
//       if (authentication) {
//         if (Date.now() >= User.time) {
//           res.status(401).json({ msg: "OTP expired" })
//         } else {
//           const authData = { otp: otp }
//           const token = jwt.
//       }
//     }
//   }
// })

export function authenticate(req: any, res: any, next: any) {
  const header = req.header("Authorization");
  console.log(header);

  const token = header && header.split(" ")[1];

  if (token === null) {
    return res.sendStatus(401);
  }
  jwt.verify(token, "bhanu01", (err: any, user: any) => {
    if (err) {
      if (err.name === "TokenExpiredError") {
        return res.status(401).json("session expired...Please login Again!");
      }
      return res.status(403).json("Something went wrong: " + err.message);
    }

    req.user = user;
    next();
  });
}

// userRouter.post("/registration", async (req: any, res: any) => {
//   const { username, password, phonenumber, address } = req.body;

//   try {
//     // validation
//     if (!phonenumber || !address || !username || !password) {
//       return res.status(400).json({ msg: "please enter all fields" });
//     }
//     let newUser: any;
//     User.findOne({ username }).then((user: any) => {
//       try {
//         newUser = new User({
//           username,
//           password,
//           phonenumber,
//           address,
//         });
//         // hashing
//         console.log(newUser);
//         bcrypt.genSalt(10, (err: any, salt: any) => {
//           bcrypt.hash(newUser.password, salt, (err: any, hash: any) => {
//             if (err) throw err;
//             newUser.password = hash;
//             newUser.save().then((user: any) => {
//               res.send(user);
//             });
//           });
//         });
//       } catch (err: any) {
//         console.log("Username already exists", err.message);
//       }
//     });
//   } catch (err: any) {
//     console.log("registration unsuccessfull", err.message);
//   }
// });

userRouter.post("/registration", async (req: any, res: any) => {
  let { username, password, phonenumber, address } = req.body;
  console.log("recieved data for registration");
  // validation
  if (!phonenumber || !address || !username || !password) {
    return res.status(400).json({ msg: "please enter all fields" });
  }
  let newUser: any;
  User.findOne({ username }).then((user: any) => {
    if (user) {
      console.log(user);
      return res.status(400).json({ msg: "user already exists" });
    }
    newUser = new User({
      username,
      password,
      phonenumber,
      address,
    });
    // hashing
    console.log(newUser);
    bcrypt.genSalt(10, (err: any, salt: any) => {
      bcrypt.hash(newUser.password, salt, (err: any, hash: any) => {
        if (err) throw err;
        newUser.password = hash;
        newUser.save().then((user: any) => {
          res.send(user);
        });
      });
    });
  });
});
