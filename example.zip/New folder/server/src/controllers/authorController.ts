import express from "express";
import book from "../models/bookModel";
export const authorRouter = express.Router();

authorRouter.get("/", async (req: any, res: any) => {
  try {
    let books = await book.distinct("author");
    res.status(200).send(books);
    console.log("my authors list", books);
  } catch (err: any) {
    res.send(400).send("something went wrong");
    console.log(err, "error");
  }
});
