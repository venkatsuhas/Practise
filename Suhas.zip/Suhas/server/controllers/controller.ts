// IMPORT MODEL HERE FROM MODELS FOLDER
import { RSA_NO_PADDING } from "constants";
import jwt from "jsonwebtoken";
const Question = require("../models/schema");
const User = require("../models/userSchema");
const Answer = require("../models/answerSchema");

function authentication(req: any, res: any, next: any) {
  const token = req.header("x-auth-token");

  try {
    //Check for token
    if (!token) {
      //401 status mean user is unauthorized
      res.status(401).json({ msg: "NO token authorization access denied" });
    }
    //Verify token
    const decoded = jwt.verify(token, "jwtSecret");

    //We now have to take the user from the token(id in the token which is the payload)
    //Add user from the payload
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).json({ msg: "Token is not valid" });
  }
}

export const getAllQuestions = async (req: any, res: any) => {
  try {
    let questions = await Question.find();
    if (questions) res.status(200).send(questions);
  } catch (err: any) {
    res.status(400).send("ERROR", err.message);
  }
};
export const postQuestion = async (req: any, res: any) => {
  let question = await new Question(req.body);

  try {
    //let userId=req.params.id;//add id in routes too
    question.save();
    let questions=await Question.find();
    res.status(200).send(question);
  } catch (err: any) {
    res.status(400).send("Failed");
  }
};
export const userRegister = async (req: any, res: any) => {
  try {
    const { name, userName, email, password } = req.body;

    //simple validation 404 is bad request
    if (!email || !password) res.status(400).send("Please enter all fields");
    //checking for existing user
    User.findOne({ email: email }).then((user: any) => {
      if (user) {
        res.status(400).send("User already exists");
      }
      const newUser = new User({
        name: name,
        userName: userName,
        email: email,
        password: password,
        //image:image
      });
      newUser.save().then((user: any) => {
        res.status(200).send(newUser);
      });
    });
  } catch (err: any) {
    res.status(400).send("Bad request");
  }
};

export const loginUser = async (req: any, res: any) => {
  const { userName, password } = req.body;

  if (!userName || !password)
    return res.status(400).json("Please enter all fields");
  User.findOne({ userName: userName }).then((user: any) => {
    if (!user) {
      return res.status(400).json("User does not exist!");
    }
    if (password == user.password) {
      jwt.sign(
        { id: user.id },
        "jwtSecret",
        { expiresIn: "120s" },
        (err, token) => {
          if (err) throw err;
          res.send({ token, id: user.id, name: user.name });
        }
      );
    }
  });
};
export const createAnswer = (req: any, res: any) => {
  let answer = new Answer({
    text: req.body.text,
    category: req.body.category,
    question: req.params.questionId,
    votes: 0,
    user: req.params.userId,
  });
  answer.save().then((answer: any) => res.send(answer));
};
export const getAnswers = async (req: any, res: any) => {
  try {
    let id = req.params.id;
    let answers = await Answer.find({ question: id });
    res.status(200).send(answers);
  } catch (err: any) {
    res.status(400).send("NO ANSWERS");
  }
};
export const getQuestionById = async (req: any, res: any) => {
  try {
    let id = req.params.id;
    let question = await Question.findOne({ _id: id });
    res.status(200).send(question);
  } catch (err: any) {
    res.status(400).send("Question Not Found");
  }
};
export const findByCategory = async (req: any, res: any) => {
  try {
    let category = new RegExp(req.params.category, "i");
    let questions = await Question.find({ category: category });
    res.status(200).send(questions);
  } catch (err: any) {
    res.status(400).send("NOT FOUND");
  }
};
export const findByText = async (req: any, res: any) => {
  try {
    let text = new RegExp(req.params.text, "i");
    let questions = await Question.find({ text });
    res.status(200).send(questions);
  } catch (err: any) {
    res.status(400).send("NOT FOUND");
  }
};
export const upVote = async (req: any, res: any) => {
  let {userId,quesId}=req.body;
  //let userId = req.params.userid;
  let newAnswers;
  //let answer = await Answer.find({ question:quesId });
  let upVotedUsers = await Answer.find({
    _id: req.params.id,
    upvotedUsers: { $elemMatch: { $eq: userId } },
  });
  let downVotedUsers = await Answer.find({
    _id: req.params.id,
    downvotedUsers: { $elemMatch: { $eq: userId } },
  });
  if (upVotedUsers.length === 0) {
    await Answer.updateOne(
      { _id: req.params.id },
      { $push: { upvotedUsers: userId } }
    );
    await Answer.updateOne(
          { _id: req.params.id },
          {
            $inc: {
              votes: +1,
            },
          }
        );
    newAnswers = await Answer.find({ question:quesId });
    //return res.status(202).send(newAnswers);
  }else{
    //return res.send(answer)
    newAnswers=await Answer.find({ question:quesId });
  }
  res.status(200).send(newAnswers);
  // try {
  //   await Answer.updateOne(
  //     { _id: req.params.id },
  //     {
  //       $inc: {
  //         votes: +1,
  //       },
  //     }
  //   );
  //   let answer = await Answer.find({question:req.params.quesId});
  //   res.send(answer);
  // } catch (err: any) {
  //   res.status(400).send("Can not increment votes");
  // }
};
export const downVote = async (req: any, res: any) => {
  // let userId = req.params.userid;
  let {userId,quesId}=req.body;

  let answer = await Answer.find({ question:quesId });
  let upVotedUsers = await Answer.find({
    _id: req.params.id,
    upvotedUsers: { $elemMatch: { $eq: userId } },
  });
  let downVotedUsers = await Answer.find({
    _id: req.params.id,
    downvotedUsers: { $elemMatch: { $eq: userId } },
  });
  if (downVotedUsers.length==0) {
    await Answer.updateOne(
      { _id: req.params.id },
      { $push: {downvotedUsers: userId } }
    );
    await Answer.updateOne(
          { _id: req.params.id },
          {
            $inc: {
              votes: -1,
            },
          }
        );
    let newAnswers = await Answer.find({ question:quesId });
    res.send(newAnswers);
  }else{
    res.send(answer)
  }




  // try {
  //   await Answer.updateOne(
  //     { _id: req.params.id },
  //     {
  //       $inc: {
  //         votes: -1,
  //       },
  //     }
  //   );
  //   let answer = await Answer.find({ question: req.params.quesId });
  //   res.send(answer);
  // } catch (err: any) {
  //   res.status(400).send("Can not increment votes");
  // }
};

export const userQuestions = async (req: any, res: any) => {
  const id = req.params.userId;
  try {
    let myQuestions = await Question.find({ user: id });
    res.status(200).send(myQuestions);
  } catch (err: any) {
    res.status(400).send("User Not Found");
  }
};
export const userAnswers = async (req: any, res: any) => {
  const id = req.params.userId;
  try {
    let myAnswers = await Answer.find({ user: id });
    res.status(200).send(myAnswers);
  } catch (err: any) {
    res.status(400).send("User Not Found");
  }
};

export const myUpVotedAnswers = async (req: any, res: any) => {
  try {
    let answers = await Answer.find({ upvotedUsers: req.params.id });
    res.status(200).send(answers);
  } catch (err: any) {
    res.status(400).send("NOT FOUND");
  }
};

export const myDownVotedAnswers = async (req: any, res: any) => {
  try {
    let answers = await Answer.find({ downVotedUsers: req.params.id });
    res.status(200).send(answers);
  } catch (err: any) {
    res.status(400).send("NOT FOUND");
  }
};
