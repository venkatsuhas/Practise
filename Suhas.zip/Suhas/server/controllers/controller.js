"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.myDownVotedAnswers = exports.myUpVotedAnswers = exports.userAnswers = exports.userQuestions = exports.downVote = exports.upVote = exports.findByText = exports.findByCategory = exports.getQuestionById = exports.getAnswers = exports.createAnswer = exports.loginUser = exports.userRegister = exports.postQuestion = exports.getAllQuestions = void 0;
var jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
var Question = require("../models/schema");
var User = require("../models/userSchema");
var Answer = require("../models/answerSchema");
function authentication(req, res, next) {
    var token = req.header("x-auth-token");
    try {
        //Check for token
        if (!token) {
            //401 status mean user is unauthorized
            res.status(401).json({ msg: "NO token authorization access denied" });
        }
        //Verify token
        var decoded = jsonwebtoken_1.default.verify(token, "jwtSecret");
        //We now have to take the user from the token(id in the token which is the payload)
        //Add user from the payload
        req.user = decoded;
        next();
    }
    catch (err) {
        res.status(400).json({ msg: "Token is not valid" });
    }
}
var getAllQuestions = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var questions, err_1;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4 /*yield*/, Question.find()];
            case 1:
                questions = _a.sent();
                if (questions)
                    res.status(200).send(questions);
                return [3 /*break*/, 3];
            case 2:
                err_1 = _a.sent();
                res.status(400).send("ERROR", err_1.message);
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.getAllQuestions = getAllQuestions;
var postQuestion = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var question, questions, err_2;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, new Question(req.body)];
            case 1:
                question = _a.sent();
                _a.label = 2;
            case 2:
                _a.trys.push([2, 4, , 5]);
                //let userId=req.params.id;//add id in routes too
                question.save();
                return [4 /*yield*/, Question.find()];
            case 3:
                questions = _a.sent();
                res.status(200).send(question);
                return [3 /*break*/, 5];
            case 4:
                err_2 = _a.sent();
                res.status(400).send("Failed");
                return [3 /*break*/, 5];
            case 5: return [2 /*return*/];
        }
    });
}); };
exports.postQuestion = postQuestion;
var userRegister = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, name_1, userName_1, email_1, password_1;
    return __generator(this, function (_b) {
        try {
            _a = req.body, name_1 = _a.name, userName_1 = _a.userName, email_1 = _a.email, password_1 = _a.password;
            //simple validation 404 is bad request
            if (!email_1 || !password_1)
                res.status(400).send("Please enter all fields");
            //checking for existing user
            User.findOne({ email: email_1 }).then(function (user) {
                if (user) {
                    res.status(400).send("User already exists");
                }
                var newUser = new User({
                    name: name_1,
                    userName: userName_1,
                    email: email_1,
                    password: password_1,
                    //image:image
                });
                newUser.save().then(function (user) {
                    res.status(200).send(newUser);
                });
            });
        }
        catch (err) {
            res.status(400).send("Bad request");
        }
        return [2 /*return*/];
    });
}); };
exports.userRegister = userRegister;
var loginUser = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, userName, password;
    return __generator(this, function (_b) {
        _a = req.body, userName = _a.userName, password = _a.password;
        if (!userName || !password)
            return [2 /*return*/, res.status(400).json("Please enter all fields")];
        User.findOne({ userName: userName }).then(function (user) {
            if (!user) {
                return res.status(400).json("User does not exist!");
            }
            if (password == user.password) {
                jsonwebtoken_1.default.sign({ id: user.id }, "jwtSecret", { expiresIn: "120s" }, function (err, token) {
                    if (err)
                        throw err;
                    res.send({ token: token, id: user.id, name: user.name });
                });
            }
        });
        return [2 /*return*/];
    });
}); };
exports.loginUser = loginUser;
var createAnswer = function (req, res) {
    var answer = new Answer({
        text: req.body.text,
        category: req.body.category,
        question: req.params.questionId,
        votes: 0,
        user: req.params.userId,
    });
    answer.save().then(function (answer) { return res.send(answer); });
};
exports.createAnswer = createAnswer;
var getAnswers = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var id, answers, err_3;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                id = req.params.id;
                return [4 /*yield*/, Answer.find({ question: id })];
            case 1:
                answers = _a.sent();
                res.status(200).send(answers);
                return [3 /*break*/, 3];
            case 2:
                err_3 = _a.sent();
                res.status(400).send("NO ANSWERS");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.getAnswers = getAnswers;
var getQuestionById = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var id, question, err_4;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                id = req.params.id;
                return [4 /*yield*/, Question.findOne({ _id: id })];
            case 1:
                question = _a.sent();
                res.status(200).send(question);
                return [3 /*break*/, 3];
            case 2:
                err_4 = _a.sent();
                res.status(400).send("Question Not Found");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.getQuestionById = getQuestionById;
var findByCategory = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var category, questions, err_5;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                category = new RegExp(req.params.category, "i");
                return [4 /*yield*/, Question.find({ category: category })];
            case 1:
                questions = _a.sent();
                res.status(200).send(questions);
                return [3 /*break*/, 3];
            case 2:
                err_5 = _a.sent();
                res.status(400).send("NOT FOUND");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.findByCategory = findByCategory;
var findByText = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var text, questions, err_6;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                text = new RegExp(req.params.text, "i");
                return [4 /*yield*/, Question.find({ text: text })];
            case 1:
                questions = _a.sent();
                res.status(200).send(questions);
                return [3 /*break*/, 3];
            case 2:
                err_6 = _a.sent();
                res.status(400).send("NOT FOUND");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.findByText = findByText;
var upVote = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, userId, quesId, newAnswers, upVotedUsers, downVotedUsers;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = req.body, userId = _a.userId, quesId = _a.quesId;
                return [4 /*yield*/, Answer.find({
                        _id: req.params.id,
                        upvotedUsers: { $elemMatch: { $eq: userId } },
                    })];
            case 1:
                upVotedUsers = _b.sent();
                return [4 /*yield*/, Answer.find({
                        _id: req.params.id,
                        downvotedUsers: { $elemMatch: { $eq: userId } },
                    })];
            case 2:
                downVotedUsers = _b.sent();
                if (!(upVotedUsers.length === 0)) return [3 /*break*/, 6];
                return [4 /*yield*/, Answer.updateOne({ _id: req.params.id }, { $push: { upvotedUsers: userId } })];
            case 3:
                _b.sent();
                return [4 /*yield*/, Answer.updateOne({ _id: req.params.id }, {
                        $inc: {
                            votes: +1,
                        },
                    })];
            case 4:
                _b.sent();
                return [4 /*yield*/, Answer.find({ question: quesId })];
            case 5:
                newAnswers = _b.sent();
                return [3 /*break*/, 8];
            case 6: return [4 /*yield*/, Answer.find({ question: quesId })];
            case 7:
                //return res.send(answer)
                newAnswers = _b.sent();
                _b.label = 8;
            case 8:
                res.status(200).send(newAnswers);
                return [2 /*return*/];
        }
    });
}); };
exports.upVote = upVote;
var downVote = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, userId, quesId, answer, upVotedUsers, downVotedUsers, newAnswers;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = req.body, userId = _a.userId, quesId = _a.quesId;
                return [4 /*yield*/, Answer.find({ question: quesId })];
            case 1:
                answer = _b.sent();
                return [4 /*yield*/, Answer.find({
                        _id: req.params.id,
                        upvotedUsers: { $elemMatch: { $eq: userId } },
                    })];
            case 2:
                upVotedUsers = _b.sent();
                return [4 /*yield*/, Answer.find({
                        _id: req.params.id,
                        downvotedUsers: { $elemMatch: { $eq: userId } },
                    })];
            case 3:
                downVotedUsers = _b.sent();
                if (!(downVotedUsers.length == 0)) return [3 /*break*/, 7];
                return [4 /*yield*/, Answer.updateOne({ _id: req.params.id }, { $push: { downvotedUsers: userId } })];
            case 4:
                _b.sent();
                return [4 /*yield*/, Answer.updateOne({ _id: req.params.id }, {
                        $inc: {
                            votes: -1,
                        },
                    })];
            case 5:
                _b.sent();
                return [4 /*yield*/, Answer.find({ question: quesId })];
            case 6:
                newAnswers = _b.sent();
                res.send(newAnswers);
                return [3 /*break*/, 8];
            case 7:
                res.send(answer);
                _b.label = 8;
            case 8: return [2 /*return*/];
        }
    });
}); };
exports.downVote = downVote;
var userQuestions = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var id, myQuestions, err_7;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                id = req.params.userId;
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                return [4 /*yield*/, Question.find({ user: id })];
            case 2:
                myQuestions = _a.sent();
                res.status(200).send(myQuestions);
                return [3 /*break*/, 4];
            case 3:
                err_7 = _a.sent();
                res.status(400).send("User Not Found");
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); };
exports.userQuestions = userQuestions;
var userAnswers = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var id, myAnswers, err_8;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                id = req.params.userId;
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                return [4 /*yield*/, Answer.find({ user: id })];
            case 2:
                myAnswers = _a.sent();
                res.status(200).send(myAnswers);
                return [3 /*break*/, 4];
            case 3:
                err_8 = _a.sent();
                res.status(400).send("User Not Found");
                return [3 /*break*/, 4];
            case 4: return [2 /*return*/];
        }
    });
}); };
exports.userAnswers = userAnswers;
var myUpVotedAnswers = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var answers, err_9;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4 /*yield*/, Answer.find({ upvotedUsers: req.params.id })];
            case 1:
                answers = _a.sent();
                res.status(200).send(answers);
                return [3 /*break*/, 3];
            case 2:
                err_9 = _a.sent();
                res.status(400).send("NOT FOUND");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.myUpVotedAnswers = myUpVotedAnswers;
var myDownVotedAnswers = function (req, res) { return __awaiter(void 0, void 0, void 0, function () {
    var answers, err_10;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4 /*yield*/, Answer.find({ downVotedUsers: req.params.id })];
            case 1:
                answers = _a.sent();
                res.status(200).send(answers);
                return [3 /*break*/, 3];
            case 2:
                err_10 = _a.sent();
                res.status(400).send("NOT FOUND");
                return [3 /*break*/, 3];
            case 3: return [2 /*return*/];
        }
    });
}); };
exports.myDownVotedAnswers = myDownVotedAnswers;
