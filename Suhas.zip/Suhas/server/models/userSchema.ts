import mongoose from "mongoose"
const Schema= mongoose.Schema;

const UserSchema= new Schema({
    name:{
        type:String,
        required:true
    },
    userName:{
        type:String,
        required:true
    },
    email:{
        type: String,
        required : true
    },
    password:{
        type: String,
        required : true
    },
    image:{
        type:String
    }
},{timestamps:true});//passing a constructor here

//creating a mode based on tht  object
const User= mongoose.model('users',UserSchema);
//books is Collection
module.exports=User;

