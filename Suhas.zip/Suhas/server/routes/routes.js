"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
//const Book = require('../book');
//const User = require('../user');
var controller_1 = require("../controllers/controller");
//IMPORT SCHEMAS HERE
var router = express_1.default.Router();
router.use(express_1.default.json());
//ALL ROUTES ARE HERE
router.route("/questions").get(controller_1.getAllQuestions).post(controller_1.postQuestion);
router.route("/questions/:id").get(controller_1.getQuestionById);
router.route("/questions/:category/category").get(controller_1.findByCategory);
router.route("/questions/:text/text").get(controller_1.findByText);
router.route("/answers/:id").get(controller_1.getAnswers); // /questions/:id/answers
router.route("/answers/:id/upvote").patch(controller_1.upVote); // /answers/:id/upvote
router.route("/answers/:id/downvote").patch(controller_1.downVote);
router.route("/answers/:questionId/:userId").post(controller_1.createAnswer); // POST /questions/:id/answers  OR POST /answers
router.route("/users/:id/upVoted").get(controller_1.myUpVotedAnswers);
router.route("/users/:id/downVoted").get(controller_1.myDownVotedAnswers);
router.route("/user").post(controller_1.userRegister);
router.route("/login").post(controller_1.loginUser);
router.route("/questions/users/:userId").get(controller_1.userQuestions);
router.route("/answers/users/:userId").get(controller_1.userAnswers);
module.exports = router;
