
const math = require('../math');
test("Calculate total Tip",()=>{
    const total=math(10,0.3);
    // if(total!==13 )
    //     throw new Error("Total should be 1.3 but got"+total);
    expect(total).toBe(13);
})

test("Should calculate tip with default tip percent",()=>{
    const total=math(10);
    expect(total).toBe(12);
})
// test("test should be async",(done)=>{
//     setTimeout(()=>{
//         expect(1).toBe(2);//This passed but this is not correct
//         done();//this done is like a middle ware
//     },2000);
// })
const add =(a,b)=>{
    return new Promise((resolve,rejects)=>{
       setTimeout(()=>{
        if(a<0||b<0)
        rejects(new Error("Number should be non negative"));
    resolve(a+b);
       },2000)
    })
}
test("Should return sum of two numbers",async()=>{
   const sum=await add(10,20);
   expect(sum).toBe(30)
})
//FOR TESTing API end points first we have to set environment of jest
//in package.json
//"jest":{"testEnvironment":"node",}
//npm i env-cmd@8.0.2 --save-dev