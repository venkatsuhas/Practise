import React, { useContext, useEffect } from 'react'
import { Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { QuestionContext } from '../Context/AppContext'
import { getUserQuestions } from '../services/services';

function MyQuestions() {
    const {state,dispatch} = useContext(QuestionContext)
    useEffect(() => {
        getUserQuestions(state.user_id,dispatch);
    }, [])
    console.log("MY QUESTIONS______",state.userQuestions);
    
    return (
        <div>
            {state.userQuestions.map(function(question:any){
              return(
                <Link to={"/GET/answers/"+question._id} id="links">
                <div className="alert alert-dark" role="alert">
                {question.text}
                </div>
                </Link>
              )
            })}
            
        </div>
    )
}

export default MyQuestions
