import React, { useContext, useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { useHistory } from "react-router";
import { QuestionContext } from "../Context/AppContext";
import {
  getAnswers,
  getQuestionById,
  addAnswer,
  incrementVote,
  decrementVote,
} from "../services/services";
//import {} from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
function Answers(props: any) {
  let id = props.match.params.id;
  const history = useHistory();
  const { state, dispatch } = useContext(QuestionContext);
  const [answer, setAnswer] = useState("");
  useEffect(() => {
    getQuestionById(id, dispatch);
    getAnswers(id, dispatch);
  }, []);
  const handleAnswer = (event: any) => {
    setAnswer(event.target.value);
  };
  const handleSubmit = () => {
    let ans = {
      text: answer,
      category: state.questionById.category,
    };
    addAnswer(dispatch, id, state.user_id, ans);
    history.push(`/GET/answers/${id}`);
  };
  const upVote = (ansId: any) => {
    if (state.isLoggedIn == false) {
      console.log("isLoggedIN in upvote", state.isLoggedIn);
      history.push("/login");
    } else {
      let upVoteParams={
        userId:state.user_id,
        quesId:state.questionById._id
      }
      incrementVote(ansId,upVoteParams,dispatch);
      history.push(`/GET/answers/${id}`);
    }
  };
  const downVote = (ansId: any) => {
    if (state.isLoggedIn == false) {
      console.log("isLoggedIN in downvote", state.isLoggedIn);

      history.push("/login");
    } else {
      let downVoteParams={
        userId:state.user_id,
        quesId:state.questionById._id
      }
      decrementVote(ansId,downVoteParams, dispatch);
      history.push(`/GET/answers/${id}`);
    }
  };
  return (
    <div>
      <h1 className="display-6">{state.questionById.text}</h1>
      <br />
      {state.answers.map(function (answer: any) {
        return (
          <div className="alert alert-dark" role="alert">
            "{answer.text}"
            <br />
            <br />
            <button className="vote">
              <i
                className="far fa-thumbs-up"
                onClick={() => upVote(answer._id)}
              ></i>
            </button>
            {/* <em>{answer.votes} votes</em> */}
            <button className="vote">
              <i
                className="far fa-thumbs-down"
                onClick={() => downVote(answer._id)}
              ></i>
            </button>
            <em>{answer.votes} votes</em>
          </div>
        );
      })}
      <h1 className="display-7">Post Answer</h1>
      <hr />

      {state.isLoggedIn ? (
        <div>
          <div className="form-floating">
            <textarea
              className="form-control"
              placeholder="Leave a comment here"
              id="floatingTextarea2"
              onChange={handleAnswer}
            ></textarea>
            <label htmlFor="floatingTextarea2">Answer</label>
            <br />
            <Button variant="dark" onClick={handleSubmit}>
              Send
            </Button>
          </div>
        </div>
      ) : (
        <div className="post-ans">Please Login to Post Answer!!</div>
      )}
    </div>
  );
}

export default Answers;
