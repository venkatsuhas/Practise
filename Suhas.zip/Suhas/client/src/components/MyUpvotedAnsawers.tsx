import React, { useContext, useEffect } from 'react'
import { Link } from 'react-router-dom';
import { QuestionContext } from '../Context/AppContext';
import { getUpvotedAnswers } from '../services/services';

function MyUpvotedAnsawers() {
    const {state,dispatch} = useContext(QuestionContext)
    useEffect(() => {
        getUpvotedAnswers(state.user_id,dispatch);
    }, [])
    return (
        <div>
            <h1>MY Answers</h1>
            {state.myupVotedAnswers.map(function(answer:any){
              return(
                <Link to={"/GET/answers/"+answer.question} id="links">
                <div className="alert alert-dark" role="alert">
                {answer.text}..
                </div>
                </Link>
              )
            })}
        </div>
    )
}

export default MyUpvotedAnsawers
