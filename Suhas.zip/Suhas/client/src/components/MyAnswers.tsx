import React, { useContext, useEffect } from 'react'
import { Link } from 'react-router-dom';
import { QuestionContext } from '../Context/AppContext';
import { getUserAnswers } from '../services/services';

function MyAnswers() {
    const {state,dispatch} = useContext(QuestionContext)
    useEffect(() => {
        getUserAnswers(state.user_id,dispatch);
    }, [])
    console.log("MY ANSWERS______",state.userAnswers);
    
    return (
        <div>
            <h1>MY Answers</h1>
            {state.userAnswers.map(function(answer:any){
              return(
                <Link to={"/GET/answers/"+answer.question} id="links">
                <div className="alert alert-dark" role="alert">
                {answer.text}..
                </div>
                </Link>
              )
            })}
            
        </div>
    )
}

export default MyAnswers
