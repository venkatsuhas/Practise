import React, { useContext, useState } from "react";
import "../App.css";
import { BrowserRouter as Router, Link, Switch, Route } from "react-router-dom";
import Question from "./Question";
import SearchBar from "./SearchBar";
import Answers from "./Answers";
import { QuestionContext } from "../Context/AppContext";
import Login from "./Login";
import Register from "./Register";
import AddQuestion from "./AddQuestion";
import { Dropdown } from "react-bootstrap";
import MyQuestions from "./MyQuestions";
import MyAnswers from "./MyAnswers";
import Avatar from 'react-avatar';
import MyUpvotedAnsawers from "./MyUpvotedAnsawers";
// import Booklist from './Booklist';
// import Carousel from './Carousel';
// import AddBook from '../components/AddBook'
// import Details from './Details';
// import Login from './Login';
// import Register from './Register';
// import SearchBar from "./SearchBar";
// import { BookContext } from '../context/AppContext';
function NaBar(props: any) {
  const { state, dispatch } = useContext(QuestionContext);
  const [modalShow, setModalShow] = useState(false);
  // const handleDropDown=()=>{
  //   <DropDown/>;
  // }
  return (
    <div className="container-fluid">
      <Router>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <img
            className="logo"
            src="https://media2.giphy.com/media/dyX9ixfxMpOUGawfdK/giphy.gif"
          />
          <h2 className="navbar-brand">Answer Me</h2>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                {/* <a className="nav-link active" aria-current="page" href="#">Home</a> */}
                <Link to="/" className="nav-link active" aria-current="page">
                  Questions
                </Link>
              </li>
              {/* <li className="nav-item">
               
                {state.isLoggedIn ? (
                  <Link
                    to="/POST/question"
                    className="nav-link active"
                    aria-current="page"
                    onClick={() => setModalShow(true)}
                  >
                    Add Question
                  </Link>
                ) : null}
              </li> */}
              <li className="nav-item"></li>
            </ul>

            <SearchBar />
            {state.isLoggedIn?<Dropdown>
              <Dropdown.Toggle
                variant="dark"
                id="dropdown-basic"
              >
            <Avatar name={state.user_Name} round={true} size="50" className="avatar" />

              </Dropdown.Toggle>

              <Dropdown.Menu>
                <Dropdown.Item>
                  <Link
                    to="/POST/question"
                    className="nav-link active"
                    aria-current="page"
                    onClick={() => setModalShow(true)}
                  >
                    Add Question
                  </Link>
                </Dropdown.Item>
                <Dropdown.Item>
                  <Link
                    to="/GET/user/questions"
                    className="nav-link active"
                    aria-current="page"
                    // onClick={() => setModalShow(true)}
                  >
                    My Questions
                  </Link>
                </Dropdown.Item>
                <Dropdown.Item>
                  <Link
                    to="/GET/user/answers"
                    className="nav-link active"
                    aria-current="page"
                    // onClick={() => setModalShow(true)}
                  >
                    My Answers
                  </Link>
                </Dropdown.Item>
                <Dropdown.Item href="#/action-3">
                 
                  <Link
                    to="/GET/user/upvoted/answers"
                    className="nav-link active"
                    aria-current="page"
                    // onClick={() => setModalShow(true)}
                  >
                    My Upvoted Answers
                  </Link>
                </Dropdown.Item>
                <Dropdown.Item>
                <Link
                to="/"
                className="nav-link active"
                onClick={() => {
                  localStorage.clear();
                  dispatch({ type: "LOGOUt" });
                }}
              >
                Logout
              </Link>
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>:null}
            {state.isLoggedIn ? null : (
              <Link
                to="/login"
                className="nav-link active"
                aria-current="page"
                id="login"
              >
                Login
              </Link>
            )}
            {/* {state.isLoggedIn ? (
              <Link
                to="/"
                className="nav-link active"
                onClick={() => {
                  localStorage.clear();
                  dispatch({ type: "LOGOUt" });
                }}
              >
                Logout
              </Link>
            ) : null} */}
          </div>
        </nav>

        <Switch>
          <Route exact path="/" component={Question} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/POST/question">
            <AddQuestion show={modalShow} onHide={() => setModalShow(false)} />
          </Route>

          <Route path="/GET/answers/:id" component={Answers} />
          <Route path="/GET/user/questions" component={MyQuestions} />
          <Route path="/GET/user/answers" component={MyAnswers} />
          <Route path="/GET/user/upvoted/answers" component={MyUpvotedAnsawers} />

        </Switch>
      </Router>
    </div>
  );
}

export default NaBar;
