import React from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import NavBar from "./components/NabBar";
function App() {
  return (
    <div>
      <NavBar/>
    </div>
  );
}

export default App;
