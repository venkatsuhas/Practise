export const Reducer = (state: any, action: any): any => {
  switch (action.type) {
    case "GET_QUESTIONS":
      return { ...state,questions:action.payload };
    case "ADD_QUESTION":
      console.log("ADD_QUES", {
        ...state,
        questions: [...state.questions, action.payload],
      });
      //return { ...state, questions: [...state.questions, action.payload] }
      return {
        ...state,
        questions: [...state.questions, action.payload],
      };
      // return {
      //   ...state,
      //   questions:action.payload,
      // };
    case "USER_QUESTIONS":
      return {
        ...state,
        userQuestions: action.payload,
      };
    case "USER_ANSWERS":
      console.log("User answers");

      return {
        ...state,
        myupVotedAnswers: action.payload,
      };
    case "USER_UPVOTED_ANSWERS":
      console.log("USER_UPVOTED_ANSWERS");

      return {
        ...state,
        myupVotedAnswers: action.payload,
      };
    case "ADD_ANSWERS":
      console.log("ADD ANS in reducer-->", {
        ...state,
        answers: [...state.answers, action.payload],
      });

      return { ...state, answers: [...state.answers, action.payload] };
    case "UP_VOTE":
      return { ...state, answers: action.payload };
    case "DOWN_VOTE":
      return { ...state, answers: action.payload };
    case "TEXT_SEARCH":
      return { ...state, questions: action.payload };
    case "CATEGORY_SEARCH":
      return { ...state, questions: action.payload };
    case "GET_ANSWERS":
      return { ...state, answers: action.payload };
    case "GET_BY_ID":
      return { ...state, questionById: action.payload };
    case "LOGIN":
      console.log("TOKEN from reducer-->", action.payload.id);

      return {
        ...state,
        isLoggedIn: true,
        token: action.payload.token,
        user_id: action.payload.id,
        user_Name: action.payload.name,
      };
    case "REGISTER":
      return { ...state };
    case "LOGOUT":
      return {
        ...state,
        isLoggedIn: false,
        token: "",
      };

    default:
      return state;
  }
};
