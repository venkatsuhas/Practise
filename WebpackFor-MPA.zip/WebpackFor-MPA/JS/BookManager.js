var table = document.getElementById("bookTable");
var Books = localStorage.getItem("MyBooks");
var data = JSON.parse(Books);
var bookManager = /** @class */ (function () {
    function bookManager() {
        //book list
        this.bookList = function () {
            for (var i = 0; i < data.length; i++) {
                var row = "<tr>\n            <td>" + data[i].id + "</td>\n            <td>" + data[i].title + "</td>\n            <td>" + data[i].author + "</td>\n            <td>" + data[i].rating + "</td>\n            <td><a href=\"#\" style=\"text-decoration:none; margin-left:35px;\" ></> <i class=\"fas fa-trash-alt delete\" ></i></a></td>\n            </tr>";
                table.innerHTML += row;
            }
            var content = document.getElementById("content");
            content.style.visibility = "visible";
            var bl = document.getElementById("bl");
            bl.style.visibility = "hidden";
        };
        //search By ID...
        this.searchById = function (searchedBooks) {
            var searchInput = document.getElementById("searchInput")
                .value;
            for (var i = 0; i < data.length; i++) {
                if (data[i].id == searchInput) {
                    searchedBooks.push(data[i]);
                }
            }
            return searchedBooks;
        };
        //search By Title...
        this.searchByTitle = function (searchedBooks) {
            var searchInput = document.getElementById("searchInput")
                .value;
            for (var i = 0; i < data.length; i++) {
                if (data[i].title == searchInput) {
                    searchedBooks.push(data[i]);
                }
            }
            return searchedBooks;
        };
        //search By Author...
        this.searchByAuthor = function (searchedBooks) {
            var searchInput = document.getElementById("searchInput")
                .value;
            for (var i = 0; i < data.length; i++) {
                if (data[i].author == searchInput) {
                    searchedBooks.push(data[i]);
                }
            }
            return searchedBooks;
        };
        //search By Rating...
        this.searchByRating = function (searchedBooks) {
            var searchInput = document.getElementById("searchInput")
                .value;
            for (var i = 0; i < data.length; i++) {
                if (data[i].rating == searchInput) {
                    searchedBooks.push(data[i]);
                }
            }
            return searchedBooks;
        };
        //search By Price...
        this.searchByPrice = function (searchedBooks) {
            var searchInput = document.getElementById("searchInput")
                .value;
            for (var i = 0; i < data.length; i++) {
                if (data[i].price == searchInput) {
                    searchedBooks.push(data[i]);
                }
            }
            return searchedBooks;
        };
        //deleting Books...
        this.deleteBook = function (e) {
            if (!e.target.classList.contains("delete")) {
                return;
            }
            var Delete = e.target;
            Delete.closest("tr").remove();
        };
    }
    return bookManager;
}());
export { bookManager };
// var data = JSON.parse(window.localStorage.getItem("MyBooks"));
// console.log(data);
