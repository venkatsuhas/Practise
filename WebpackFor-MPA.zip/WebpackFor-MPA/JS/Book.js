var Book = /** @class */ (function () {
    function Book(id, title, author, rating, price, coverPhotoUrl) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.rating = rating;
        this.price = price;
        this.coverPhotoUrl = coverPhotoUrl;
    }
    return Book;
}());
export { Book };
;
