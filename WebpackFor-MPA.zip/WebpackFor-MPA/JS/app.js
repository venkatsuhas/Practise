import { bookManager } from "./BookManager";
var book = new bookManager();
var list = document.getElementById("bl");
list.addEventListener("click", book.bookList);
var tableEl = document.querySelector("table");
tableEl.addEventListener("click", book.deleteBook);
//search Results...
function searchResults(searchedBooks) {
    var table = document.getElementById("bookTable");
    var tablerows = document.querySelectorAll('tbody');
    for (var _i = 0, tablerows_1 = tablerows; _i < tablerows_1.length; _i++) {
        var row_1 = tablerows_1[_i];
        row_1.remove();
    }
    for (var _a = 0, searchedBooks_1 = searchedBooks; _a < searchedBooks_1.length; _a++) {
        var b = searchedBooks_1[_a];
        var row = "<tr>\n        <td>" + b.id + "</td>\n        <td>" + b.title + "</td>\n        <td>" + b.author + "</td>\n        <td>" + b.rating + "</td>\n        <td>" + b.price + "</td>\n       <td><a href=\"#\" style=\"text-decoration:none;margin-left:35px;\" ></> <i class=\"fas fa-trash-alt delete\" ></i></a></td>\n        </tr>";
        table.innerHTML += row;
    }
}
var searchBtn = document.getElementById("search");
searchBtn.addEventListener('click', function (e) {
    e.preventDefault();
    var option = document.getElementById("choice");
    var optionValue = option.value;
    var search = document.getElementById("searchInput");
    var searchInput = search.value;
    var searchedBooks = [];
    switch (optionValue) {
        case "id":
            if (searchInput != null) {
                var searchedBooksById = book.searchById(searchedBooks);
                searchResults(searchedBooksById);
            }
        case "title":
            if (searchInput != null) {
                var searchedBooksByTitle = book.searchByTitle(searchedBooks);
                searchResults(searchedBooksByTitle);
            }
        case "author":
            if (searchInput != null) {
                var searchedBooksByAuthor = book.searchByAuthor(searchedBooks);
                searchResults(searchedBooksByAuthor);
            }
        case "rating":
            if (searchInput != null) {
                var searchedBooksByRating = book.searchByRating(searchedBooks);
                searchResults(searchedBooksByRating);
            }
        case "price":
            if (searchInput != null) {
                var searchedBooksByPrice = book.searchByPrice(searchedBooks);
                searchResults(searchedBooksByPrice);
            }
    }
});
