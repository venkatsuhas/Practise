import { Book } from "./Book";
var Books = [];
var addBook = function (e) {
    e.preventDefault();
    var id = document.getElementById("Id").value;
    var title = document.getElementById("Title").value;
    var author = document.getElementById("Author").value;
    var rating = document.getElementById("Rating").value;
    var price = document.getElementById("Price").value;
    Books.push(new Book(id, title, author, rating, price));
    localStorage.setItem("MyBooks", JSON.stringify(Books));
};
var add = document.getElementById("form");
add.addEventListener("submit", addBook);
