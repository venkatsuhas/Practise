import React, { useContext, useEffect, useState } from 'react'
import { BookContext } from "../Context/BookContext";
import { Route, NavLink, HashRouter } from "react-router-dom";
import { getAllAuthors,  getBookByAuthor } from '../services/service';
import AuthorsBooks from './authorsbooks';
function Authors() {

    const { state, dispatch } = useContext(BookContext);
    console.log("Authors comp")

    const [colors, setColors] = useState("")
    useEffect(() => {
        getAllAuthors(dispatch)
            .then((res:any) => {
                console.log("response fom getallauthors comp",res)
            })
    }, [])


    return (

        <div>
        
            {state.isTitle ? <h1 id="ttlfont">Click on any author for details</h1> : null}
            <div className="authordetails">{state.isDisplayed ? <AuthorsBooks /> : null} </div>
            {state.author_names.map((author: any) => {
                return (

                    <div className="auth">
                        {/* <NavLink to={"/authorsbooks/"+book}> */}
                        <div
                            id={author}
                            onClick={() => {
                                // getBookByAuthor(dispatch, author);
                                getBookByAuthor(dispatch,author)
                                setColors(author)
                            }}>
                            {colors === author ? <h2 style={{ color: 'blueviolet' }} className="card-title" id='bk'>  {author}</h2> : <h2 className="card-title" id='bk'>  {author}</h2>}

                        </div>
                        {/* </NavLink> */}
                    </div>
                )
            }
            )}
        </div>
    )
}

export default Authors
