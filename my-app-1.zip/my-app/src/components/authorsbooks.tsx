import React, { useEffect, useContext } from "react";
import Details from "./details"
import { BookContext } from "../Context/BookContext";
import { getBookById } from "../services/service"
import {
    Route,
    NavLink,
    HashRouter
} from "react-router-dom";

import { StarComponent } from "./starrating";

// import { getAllBooks } from "../services/service";



function AuthorsBooks() {
    const { state, dispatch,bookByIdFunction ,myFunction} = useContext(BookContext);


    useEffect(() => {
       myFunction()
    }, []
    )



    return (
        <div>
           {/* <h1 id="ttlfont">Click on any book for details</h1> */}
            {state.author.map((book: any) => {
                return (
                    <div>
                        <NavLink to={"/details/" + book._id}>
                            <div className="card"
                                id={book._id}
                                onClick={() => {
                                    bookByIdFunction( book._id);
                                }}>

                                <div className="card-body">
                                    <img id="img" src={book.cover} alt={book.title} />
                                    <h1 className="card-title" id='ttl'>{book.title}</h1>
                                    <div>Rating:<span className="stars"><StarComponent rating={book.rating} outof={5} minof={1}></StarComponent></span></div>
                                    <p className="card-subtitle mb-2 text-muted" id="cost"><strong>Cost:{book.cost}</strong></p>
                                </div><br></br><br></br>
                                <button className="detailsbtn"> Details</button>
                            </div>

                        </NavLink>
                        <Route path={"/details/" + book._id} component={Details} />
                    </div>
                )

            })}

        </div>
    )
}

export default AuthorsBooks;