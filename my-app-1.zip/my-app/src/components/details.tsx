import React, { useContext, useEffect, useState, Component } from 'react';
import { RouteComponentProps, useHistory, useParams } from 'react-router';
import { Route, Link, HashRouter } from "react-router-dom";
import { BookContext } from '../Context/BookContext'
import { deleteBook } from '../services/service'
import { StarComponent } from './starrating';




function Details(props: any) {
    const { id } = useParams<any>();
    const { state, bookByIdFunction } = useContext(BookContext);
    console.log(state, "state from details component")

    // console.log("selectedBook: " + SelectedBook);
    const { dispatch } = useContext(BookContext);
    const history = useHistory();





    const [selectedBook, setselectedBook] = useState<any>(null)

    useEffect(() => {
        if (state != undefined) {
            setselectedBook(state.selectedBook)
        }
    }, [state.selectedBook]
    )



    return (
        <div className="fulldetails">
            {selectedBook === null ? <h3>Loading</h3> : <div>
                <div className="detailpge vertical-line" >
                    {/* <img id="imgDetails" src={SelectedBook.cover} /> */}

                    <p><strong>Author:{selectedBook.author}</strong></p>
                    <div>Rating:<span className="stars"><StarComponent rating={selectedBook.rating} outof={5} minof={1}></StarComponent></span></div>
                    <p><strong>Price :₹{selectedBook.cost}</strong></p>
                    <h1>{selectedBook.title}</h1>
                    <p><strong>{selectedBook.description}</strong></p>
                    {state.isLoggedIn ? <button id='delbtn' onClick={() => {
                        deleteBook(id, dispatch);
                        history.push("/booklist")
                    }}>DELETE</button> : null}
                    <div>

                    </div>
                </div>
                <div className="img ">
                <img id="imgDetails" src={selectedBook.cover} />
            </div>
            </div>}
          
        </div>
    );

} export default Details;