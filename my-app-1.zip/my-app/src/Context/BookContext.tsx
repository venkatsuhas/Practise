import react, { createContext, useReducer } from "react";
import { Reducer } from "../Context/BookReducer";
import { getBookList } from "../services/service"
export const BookContext = createContext<any>({});
import { getBookById } from "../services/service";

export const BookProvider = (props: any) => {
    const [state, dispatch] = useReducer(Reducer, {}, () => {
        return {
            books: [],
            users: [],
            isLoggedIn: false,
            isDisplayed: false,
            isTitle: true,
            token: "",
            searchText: "",
            selected: '',
            selectedBook: {},
            author_names: [],
            author: [],
            status: "",
        }
    })



    function outerFunction(getBooks: any, actionname: any) {
        return async (...params: any) => {
            try {
                dispatch({ type: actionname + "_PENDING" })
                let response = await getBooks(...params)
                console.log(response, "resp from closure")
                dispatch({ type: actionname, payload: response })
            }
            catch (err) {
                console.log(err.message)
                dispatch({ type: actionname + "_ERROR", payload: err.message })
            }
        }
    }

    const myFunction = outerFunction(getBookList, "GET_BOOKS")
    const bookByIdFunction = outerFunction(getBookById, "GET_BOOKS_BY_ID")
    return (
        <BookContext.Provider value={{ state, dispatch, myFunction, bookByIdFunction }}>
            {props.children}
        </BookContext.Provider>
    )
}

